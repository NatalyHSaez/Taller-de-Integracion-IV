import type {
  AuthTokensResponse,
  CurrentUserResponse,
  UserRole,
} from '../../../../src/core/infrastructure/http/dto';
import { ApiError } from '../../../../src/core/infrastructure/http/errors';
import {
  MOCK_ACCOUNTS,
  MOCK_AUTH_TOKENS,
  type MockAccount,
} from './api-data';

let currentAccount: MockAccount | null = null;

/** Busca una cuenta ficticia usando las credenciales escritas en el login. */
export function findMockAccount(email: string, password: string): MockAccount | undefined {
  const normalizedEmail = email.trim().toLowerCase();

  return MOCK_ACCOUNTS.find(
    (account) =>
      account.email.toLowerCase() === normalizedEmail &&
      account.password === password,
  );
}

/** Indica si el correo pertenece al conjunto explícito de cuentas mock. */
export function isMockAccountEmail(email: string): boolean {
  const normalizedEmail = email.trim().toLowerCase();

  return MOCK_ACCOUNTS.some(
    (account) => account.email.toLowerCase() === normalizedEmail,
  );
}

function mockRoleToApiRole(role: MockAccount['role']): UserRole {
  return role;
}

/**
 * Simula POST /api/v1/auth/login utilizando la misma forma de respuesta
 * que el backend real de Integración II.
 */
export async function mockLogin(
  email: string,
  password: string,
): Promise<AuthTokensResponse> {
  const account = findMockAccount(email, password);

  if (!account) {
    throw new ApiError({
      code: 'INVALID_CREDENTIALS',
      message: 'Correo o contraseña incorrectos.',
      details: {},
      status: 401,
    });
  }

  currentAccount = account;

  return {
    ...MOCK_AUTH_TOKENS,
    accessToken: `${MOCK_AUTH_TOKENS.accessToken}-${account.userId}`,
    refreshToken: `${MOCK_AUTH_TOKENS.refreshToken}-${account.userId}`,
  };
}

/** Simula GET /api/v1/me con el contrato real actual. */
export async function mockMe(): Promise<CurrentUserResponse> {
  if (!currentAccount) {
    throw new ApiError({
      code: 'AUTHENTICATION_REQUIRED',
      message: 'No existe una sesión mock activa.',
      details: {},
      status: 401,
    });
  }

  return {
    id: currentAccount.userId,
    fullName: `${currentAccount.firstName} ${currentAccount.lastName}`,
    email: currentAccount.email,
    roles: [mockRoleToApiRole(currentAccount.role)],
  };
}

export function getCurrentMockAccount(): MockAccount | null {
  return currentAccount;
}

export function mockLogout(): void {
  currentAccount = null;
}
