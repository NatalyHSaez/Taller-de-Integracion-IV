import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ReadingConfirmationModal } from "@/src/modules/monitoring/presentation/components/reading-confirmation";
import { ReadingResult } from "@/src/modules/monitoring/presentation/components/reading-result";
import { ThemedText } from "@/src/shared/presentation/components/themed-text";
import { ThemedView } from "@/src/shared/presentation/components/themed-view";
import { BrandColors, Colors, MeasurementColors } from "@/src/shared/presentation/theme";
import { useAppState } from "@/src/core/presentation/session/use-app-state";
import { useClinicalParameters } from "@/src/modules/monitoring/presentation/hooks/use-clinical-parameters";
import { useColorScheme } from "@/src/shared/presentation/hooks/use-color-scheme";
import {
  clinicalParametersService,
  validateAgainstParameter,
} from "@/src/modules/monitoring/application/clinical-parameters";
import { createReadingFlow } from "@/src/modules/monitoring/application/reading-flow";
import {
  buildCreateReadingRequest,
  READING_CONTEXT_LABELS,
  readingsService,
  resolveActivePatientId,
} from "@/src/modules/monitoring/application/readings";
import type {
  ClinicalParameterCode,
  ClinicalParameterResponse,
  CreateReadingRequest,
  ReadingContext,
} from "@/src/core/domain/contracts";
import type { MeasurementType } from "@/src/modules/monitoring/domain/measurement";
import { useRouter } from "expo-router";

type MeasuredAtError = Error & { field: "measuredAt" };

/** El formulario captura las tres mediciones compuestas; los tipos aislados solo se muestran en historial y gráficos. */
type FormMeasurementType = Extract<MeasurementType, 'blood_pressure' | 'glucose' | 'weight'>;

type MeasurementOption = {
  value: FormMeasurementType;
  label: string;
  icon: "heart-pulse" | "water-outline" | "scale-bathroom";
};

const MEASUREMENT_OPTIONS: MeasurementOption[] = [
  {
    value: "blood_pressure",
    label: "Presión",
    icon: "heart-pulse",
  },
  {
    value: "glucose",
    label: "Glucosa",
    icon: "water-outline",
  },
  {
    value: "weight",
    label: "Peso",
    icon: "scale-bathroom",
  },
];

/** Parámetros del catálogo que necesita cada tipo de formulario. */
const REQUIRED_PARAMETERS: Record<FormMeasurementType, ClinicalParameterCode[]> = {
  blood_pressure: ["SBP", "DBP", "HEART_RATE"],
  glucose: ["GLUCOSE"],
  weight: ["WEIGHT"],
};

/** Pista con el rango técnico efectivo (viene de la API, no de constantes locales). */
function rangeHint(parameter: ClinicalParameterResponse) {
  const { technicalMin: min, technicalMax: max, unit } = parameter;
  if (min !== null && max !== null) return `Rango aceptado: ${min}–${max} ${unit}`;
  if (min !== null) return `Mínimo: ${min} ${unit}`;
  if (max !== null) return `Máximo: ${max} ${unit}`;
  return undefined;
}

/** El backend exige PREPRANDIAL o POSTPRANDIAL para glucosa. */
const GLUCOSE_CONTEXTS: { value: ReadingContext; label: string }[] = (
  ["PREPRANDIAL", "POSTPRANDIAL"] as const
).map((value) => ({ value, label: READING_CONTEXT_LABELS[value] }));

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("es-CL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function formatTime(date: Date) {
  return new Intl.DateTimeFormat("es-CL", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date);
}

export default function RegisterMeasurementScreen() {
  const router = useRouter();
  const { selectedPatient: patient, user } = useAppState();
  const [saveError, setSaveError] = useState("");
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const themeName = isDark ? "dark" : "light";
  const theme = Colors[themeName];
  const insets = useSafeAreaInsets();
  const now = useMemo(() => new Date(), []);

  const [measurementType, setMeasurementType] =
    useState<FormMeasurementType>("blood_pressure");
  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [heartRate, setHeartRate] = useState("");
  const [glucose, setGlucose] = useState("");
  const [glucoseContext, setGlucoseContext] = useState<ReadingContext | null>(
    null,
  );
  const [weight, setWeight] = useState("");
  const [date, setDate] = useState(formatDate(now));
  const [time, setTime] = useState(formatTime(now));
  const [showReview, setShowReview] = useState(false);
  // Flujo envío → confirmación → resultado (src/modules/monitoring/application/reading-flow.ts).
  const flow = useMemo(() => createReadingFlow(readingsService), []);
  const flowState = useSyncExternalStore(flow.subscribe, flow.getState, flow.getState);
  const submitting = flowState.step === "submitting";
  const serverErrors =
    flowState.step === "form" ? (flowState.errors?.fields ?? {}) : {};
  const serverGeneralError =
    flowState.step === "form" ? (flowState.errors?.general ?? "") : "";
  const [submittedSummary, setSubmittedSummary] = useState("");
  const {
    catalog,
    loading: catalogLoading,
    error: catalogError,
    retry: retryCatalog,
  } = useClinicalParameters();

  const isTypeAvailable = (type: FormMeasurementType) =>
    !!catalog && REQUIRED_PARAMETERS[type].every((code) => !!catalog[code]);
  const typeAvailable = isTypeAvailable(measurementType);
  const parameter = (code: ClinicalParameterCode) => catalog?.[code];
  const unitOf = (code: ClinicalParameterCode) => parameter(code)?.unit ?? "";

  useEffect(() => {
    let active = true;
    void Promise.resolve().then(() => {
      if (!active || !catalog) return;
      setMeasurementType((current) => {
        if (REQUIRED_PARAMETERS[current].every((code) => !!catalog[code])) return current;
        return MEASUREMENT_OPTIONS.find((option) =>
          REQUIRED_PARAMETERS[option.value].every((code) => !!catalog[code]),
        )?.value ?? current;
      });
    });
    return () => { active = false; };
  }, [catalog]);

  const fieldValues: Record<ClinicalParameterCode, string> = {
    SBP: systolic,
    DBP: diastolic,
    HEART_RATE: heartRate,
    GLUCOSE: glucose,
    WEIGHT: weight,
  };
  const fieldErrors: Partial<Record<ClinicalParameterCode, string>> = {};
  if (catalog) {
    for (const code of REQUIRED_PARAMETERS[measurementType]) {
      const definition = catalog[code];
      const message = definition
        ? validateAgainstParameter(definition, fieldValues[code])
        : null;
      if (message) fieldErrors[code] = message;
    }
  }
  const hasFieldErrors = Object.keys(fieldErrors).length > 0;

  /** Al editar cualquier dato se descartan los errores devueltos por el servidor. */
  function edited<T>(setter: (value: T) => void) {
    return (value: T) => {
      setter(value);
      flow.clearErrors();
      setSaveError("");
    };
  }

  const accentColor = theme.primary;
  const surfaceColor = theme.surface;
  const borderColor = theme.border;
  const inputColor = theme.surfaceMuted;

  // Los rangos solo los decide validateAgainstParameter con los límites de la API;
  // aquí solo se exige que los campos requeridos estén completos.
  const formIsValid =
    typeAvailable &&
    !hasFieldErrors &&
    date.trim().length > 0 &&
    time.trim().length > 0 &&
    REQUIRED_PARAMETERS[measurementType].every(
      (code) => fieldValues[code].trim().length > 0,
    ) &&
    (measurementType !== "glucose" || glucoseContext !== null);

  const selectedOption = MEASUREMENT_OPTIONS.find(
    (option) => option.value === measurementType,
  )!;
  const selectedColors = MeasurementColors[themeName][measurementType];

  function selectMeasurementType(value: FormMeasurementType) {
    setMeasurementType(value);
    setShowReview(false);
    flow.clearErrors();
    setSaveError("");
  }

  function getSummaryValue() {
    if (measurementType === "blood_pressure") {
      return `${systolic} / ${diastolic} ${unitOf("SBP")} · ${heartRate} ${unitOf("HEART_RATE")}`;
    }
    if (measurementType === "glucose") return `${glucose} ${unitOf("GLUCOSE")}`;
    return `${weight.replace(".", ",")} ${unitOf("WEIGHT")}`;
  }

  const contextLabel = GLUCOSE_CONTEXTS.find(
    (item) => item.value === glucoseContext,
  )?.label;
  function renderParameterInput(
    code: ClinicalParameterCode,
    value: string,
    onChangeText: (value: string) => void,
    placeholder: string,
    decimal = false,
  ) {
    const definition = parameter(code);
    if (!definition) return null;
    return (
      <MeasurementInput
        key={code}
        label={definition.name}
        value={value}
        onChangeText={edited(onChangeText)}
        unit={definition.unit}
        hint={rangeHint(definition)}
        error={fieldErrors[code] ?? serverErrors[code]}
        placeholder={placeholder}
        inputColor={inputColor}
        borderColor={borderColor}
        textColor={theme.text}
        placeholderColor={theme.placeholder}
        decimal={decimal}
      />
    );
  }

  function parseMeasuredAt(): Date {
    const [day, month, year] = date.split(/[/-]/).map(Number);
    const [hour, minute] = time.split(":").map(Number);
    const measured = new Date(year, month - 1, day, hour, minute);
    if (
      !/^\d{2}[/-]\d{2}[/-]\d{4}$/.test(date) ||
      !/^\d{2}:\d{2}$/.test(time) ||
      measured.getFullYear() !== year ||
      measured.getMonth() !== month - 1 ||
      measured.getDate() !== day ||
      hour > 23 ||
      minute > 59 ||
      !Number.isFinite(measured.getTime())
    ) {
      throw Object.assign(new Error("Revisa la fecha (dd/mm/aaaa) y la hora (hh:mm)."), {
        field: "measuredAt" as const,
      });
    }
    if (measured.getTime() > Date.now()) {
      throw Object.assign(new Error("La fecha y hora no pueden ser futuras."), {
        field: "measuredAt" as const,
      });
    }
    return measured;
  }

  async function save() {
    if (!formIsValid || flow.getState().step !== "form") return;
    if (!showReview) {
      setShowReview(true);
      return;
    }

    setSaveError("");
    flow.clearErrors();

    let measured: Date;
    let patientId: string;
    let request: CreateReadingRequest;
    try {
      measured = parseMeasuredAt();
      patientId = resolveActivePatientId();
      request = buildCreateReadingRequest({
        codes: REQUIRED_PARAMETERS[measurementType],
        values: fieldValues,
        catalog: catalog ?? {},
        context: measurementType === "glucose" ? glucoseContext : null,
        measuredAt: measured,
      });
    } catch (cause) {
      const error = cause as Partial<MeasuredAtError>;
      if (error.field === "measuredAt") {
        flow.showFormErrors({
          fields: { measuredAt: error.message ?? "" },
          general: null,
          unitRejected: false,
        });
      } else {
        setSaveError(error.message || "No se pudo preparar la medición.");
      }
      return;
    }

    setSubmittedSummary(getSummaryValue());
    await flow.submit(patientId, request);

    const after = flow.getState();
    if (after.step === "form" && after.errors?.unitRejected) {
      clinicalParametersService.invalidate();
      retryCatalog();
    }
  }

  async function confirmReading() {
    await flow.confirm();
  }

  function goToHistory() {
    router.replace("/historial");
  }

  function startNewReading() {
    setSystolic("");
    setDiastolic("");
    setHeartRate("");
    setGlucose("");
    setGlucoseContext(null);
    setWeight("");
    const current = new Date();
    setDate(formatDate(current));
    setTime(formatTime(current));
    setShowReview(false);
    setSaveError("");
    flow.reset();
  }

  return (
    <ThemedView style={styles.screen}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.screen}
      >
        <ScrollView
          contentContainerStyle={[
            styles.content,
            { paddingBottom: Math.max(insets.bottom + 24, 36) },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <ThemedText>
            Paciente: {patient?.name} · Registra: {user?.name}
          </ThemedText>
          <View style={styles.hero}>
            <View style={styles.heroDecorationTop} />
            <View style={styles.heroDecorationBottom} />
            <View style={styles.heroIcon}>
              <MaterialCommunityIcons
                name="heart-plus"
                size={31}
                color={BrandColors.onPrimary}
              />
            </View>
            <ThemedText
              lightColor={BrandColors.onPrimary}
              darkColor={BrandColors.onPrimary}
              style={styles.heroTitle}
            >
              Nueva medición
            </ThemedText>
            <ThemedText
              lightColor={BrandColors.onPrimaryMuted}
              darkColor={BrandColors.onPrimaryMuted}
              style={styles.heroDescription}
            >
              Ingresa los datos tal como aparecen en tu dispositivo de medición.
            </ThemedText>
          </View>

          {catalogLoading && !catalog && (
            <View
              accessibilityLiveRegion="polite"
              style={[styles.statusCard, { backgroundColor: surfaceColor, borderColor }]}
            >
              <ActivityIndicator color={accentColor} />
              <ThemedText style={styles.statusText}>
                Cargando tipos de medición…
              </ThemedText>
            </View>
          )}

          {!catalogLoading && catalogError && (
            <View
              accessibilityRole="alert"
              style={[styles.statusCard, { backgroundColor: surfaceColor, borderColor }]}
            >
              <MaterialCommunityIcons
                name="cloud-alert-outline"
                size={26}
                color={theme.icon}
              />
              <ThemedText style={styles.statusText}>{catalogError}</ThemedText>
              <Pressable
                accessibilityRole="button"
                onPress={retryCatalog}
                style={({ pressed }) => [
                  styles.retryButton,
                  { backgroundColor: accentColor },
                  pressed && styles.pressed,
                ]}
              >
                <ThemedText
                  lightColor={BrandColors.onPrimary}
                  darkColor={BrandColors.onPrimary}
                  style={styles.retryLabel}
                >
                  Reintentar
                </ThemedText>
              </Pressable>
            </View>
          )}

          {(flowState.step === "result" || flowState.step === "unconfirmed") && (
            <ReadingResult
              reading={flowState.reading}
              summary={submittedSummary}
              unconfirmed={flowState.step === "unconfirmed"}
              refreshing={flowState.step === "result" && flowState.refreshing}
              refreshError={flowState.step === "result" ? flowState.refreshError : null}
              theme={theme}
              onRefresh={flow.refresh}
              onConfirmNow={flow.reopen}
              onGoToHistory={goToHistory}
              onNewReading={startNewReading}
            />
          )}

          {catalog && flowState.step !== "result" && flowState.step !== "unconfirmed" && (
            <>
            <View style={styles.sectionHeading}>
              <View style={styles.stepBadge}>
                <ThemedText
                  lightColor={BrandColors.onPrimary}
                  darkColor={BrandColors.onPrimary}
                  style={styles.stepBadgeText}
                >
                  1
                </ThemedText>
              </View>
              <ThemedText accessibilityRole="header" style={styles.sectionTitle}>
                Tipo de medición
              </ThemedText>
            </View>

            <View accessibilityRole="radiogroup" style={styles.typeRow}>
              {MEASUREMENT_OPTIONS.map((option) => {
                const isSelected = measurementType === option.value;
                const isAvailable = isTypeAvailable(option.value);
                const optionColors = MeasurementColors[themeName][option.value];
                return (
                  <Pressable
                    key={option.value}
                    accessibilityLabel={option.label}
                    accessibilityRole="radio"
                    accessibilityState={{
                      checked: isSelected,
                      disabled: !isAvailable,
                    }}
                    disabled={!isAvailable}
                    onPress={() => selectMeasurementType(option.value)}
                    style={({ pressed }) => [
                      styles.typeCard,
                      {
                        backgroundColor: surfaceColor,
                        borderColor: isSelected
                          ? optionColors.accent
                          : borderColor,
                      },
                      isSelected && styles.typeCardSelected,
                      !isAvailable && styles.typeCardDisabled,
                      pressed && styles.pressed,
                    ]}
                  >
                    <View
                      style={[
                        styles.typeIcon,
                        { backgroundColor: optionColors.background },
                      ]}
                    >
                      <MaterialCommunityIcons
                        name={option.icon}
                        size={25}
                        color={optionColors.accent}
                      />
                    </View>
                    <ThemedText style={styles.typeLabel}>
                      {option.label}
                    </ThemedText>
                    {isSelected && (
                      <MaterialCommunityIcons
                        name="check-circle"
                        size={19}
                        color={optionColors.accent}
                        style={styles.checkIcon}
                      />
                    )}
                  </Pressable>
                );
              })}
            </View>

            <View style={styles.sectionHeading}>
              <View style={styles.stepBadge}>
                <ThemedText
                  lightColor={BrandColors.onPrimary}
                  darkColor={BrandColors.onPrimary}
                  style={styles.stepBadgeText}
                >
                  2
                </ThemedText>
              </View>
              <ThemedText accessibilityRole="header" style={styles.sectionTitle}>
                Ingresa los valores
              </ThemedText>
            </View>

            <View
              style={[
                styles.formCard,
                { backgroundColor: surfaceColor, borderColor },
              ]}
            >
              {!typeAvailable && (
                <ThemedText style={[styles.fieldHelp, { color: theme.icon }]}>
                  Este tipo de medición no está disponible en el catálogo actual.
                </ThemedText>
              )}

              {typeAvailable && measurementType === "blood_pressure" && (
                <>
                  <View style={styles.twoColumns}>
                    {renderParameterInput("SBP", systolic, setSystolic, "120")}
                    {renderParameterInput("DBP", diastolic, setDiastolic, "80")}
                  </View>
                  {renderParameterInput("HEART_RATE", heartRate, setHeartRate, "72")}
                </>
              )}

              {typeAvailable && measurementType === "glucose" && (
                <>
                  {renderParameterInput("GLUCOSE", glucose, setGlucose, "105")}
                  <View style={styles.fieldGroup}>
                    <ThemedText style={styles.inputLabel}>
                      Contexto de la medición
                    </ThemedText>
                    <ThemedText style={[styles.fieldHelp, { color: theme.icon }]}>
                      Necesario para interpretar correctamente la glucosa.
                    </ThemedText>
                    <View
                      accessibilityRole="radiogroup"
                      style={styles.contextOptions}
                    >
                      {GLUCOSE_CONTEXTS.map((item) => {
                        const isSelected = glucoseContext === item.value;
                        return (
                          <Pressable
                            key={item.value}
                            accessibilityRole="radio"
                            accessibilityState={{ checked: isSelected }}
                            onPress={() => edited(setGlucoseContext)(item.value)}
                            style={({ pressed }) => [
                              styles.contextButton,
                              {
                                backgroundColor: isSelected
                                  ? accentColor
                                  : inputColor,
                                borderColor: isSelected
                                  ? accentColor
                                  : borderColor,
                              },
                              pressed && styles.pressed,
                            ]}
                          >
                            <ThemedText
                              lightColor={
                                isSelected ? theme.onPrimary : theme.text
                              }
                              darkColor={
                                isSelected ? theme.onPrimary : theme.text
                              }
                              style={[
                                styles.contextLabel,
                                isSelected && styles.contextLabelSelected,
                              ]}
                            >
                              {item.label}
                            </ThemedText>
                          </Pressable>
                        );
                      })}
                    </View>
                    {!!serverErrors.context && (
                      <ThemedText accessibilityRole="alert" style={styles.fieldError}>
                        {serverErrors.context}
                      </ThemedText>
                    )}
                  </View>
                </>
              )}

              {typeAvailable && measurementType === "weight" &&
                renderParameterInput("WEIGHT", weight, setWeight, "78,5", true)}
            </View>

            <View style={styles.sectionHeading}>
              <View style={styles.stepBadge}>
                <ThemedText
                  lightColor={BrandColors.onPrimary}
                  darkColor={BrandColors.onPrimary}
                  style={styles.stepBadgeText}
                >
                  3
                </ThemedText>
              </View>
              <ThemedText accessibilityRole="header" style={styles.sectionTitle}>
                Fecha y hora
              </ThemedText>
            </View>

            <View
              style={[
                styles.formCard,
                styles.dateCard,
                { backgroundColor: surfaceColor, borderColor },
              ]}
            >
              <View style={styles.dateField}>
                <ThemedText style={styles.inputLabel}>Fecha</ThemedText>
                <View
                  style={[
                    styles.inputShell,
                    { backgroundColor: inputColor, borderColor },
                  ]}
                >
                  <MaterialCommunityIcons
                    name="calendar-outline"
                    size={21}
                    color={accentColor}
                  />
                  <TextInput
                    accessibilityLabel="Fecha de la medición"
                    onChangeText={edited(setDate)}
                    placeholder="DD/MM/AAAA"
                    placeholderTextColor={theme.icon}
                    style={[styles.dateInput, { color: theme.text }]}
                    value={date}
                  />
                </View>
              </View>
              <View style={styles.timeField}>
                <ThemedText style={styles.inputLabel}>Hora</ThemedText>
                <View
                  style={[
                    styles.inputShell,
                    { backgroundColor: inputColor, borderColor },
                  ]}
                >
                  <MaterialCommunityIcons
                    name="clock-outline"
                    size={21}
                    color={accentColor}
                  />
                  <TextInput
                    accessibilityLabel="Hora de la medición"
                    onChangeText={edited(setTime)}
                    placeholder="HH:MM"
                    placeholderTextColor={theme.icon}
                    style={[styles.dateInput, { color: theme.text }]}
                    value={time}
                  />
                </View>
              </View>
            </View>
            {!!serverErrors.measuredAt && (
              <ThemedText accessibilityRole="alert" style={styles.fieldError}>
                {serverErrors.measuredAt}
              </ThemedText>
            )}

            {showReview && formIsValid && (
              <View
                style={[
                  styles.reviewCard,
                  {
                    backgroundColor: surfaceColor,
                    borderColor: selectedColors.accent,
                  },
                ]}
              >
                <View
                  style={[
                    styles.reviewIcon,
                    { backgroundColor: selectedColors.background },
                  ]}
                >
                  <MaterialCommunityIcons
                    name={selectedOption.icon}
                    size={25}
                    color={selectedColors.accent}
                  />
                </View>
                <View style={styles.reviewCopy}>
                  <ThemedText style={styles.reviewEyebrow}>
                    REVISA ANTES DE GUARDAR
                  </ThemedText>
                  <ThemedText style={styles.reviewTitle}>
                    {selectedOption.label}
                  </ThemedText>
                  <ThemedText style={styles.reviewValue}>
                    {getSummaryValue()}
                  </ThemedText>
                  {contextLabel && (
                    <ThemedText
                      style={[styles.reviewMeta, { color: theme.icon }]}
                    >
                      {contextLabel}
                    </ThemedText>
                  )}
                  <ThemedText style={[styles.reviewMeta, { color: theme.icon }]}>
                    {date} · {time}
                  </ThemedText>
                </View>
              </View>
            )}

            {!!(saveError || serverGeneralError) && (
              <View
                accessibilityRole="alert"
                style={[
                  styles.saveError,
                  { backgroundColor: theme.dangerBackground, borderColor: theme.dangerBorder },
                ]}
              >
                <MaterialCommunityIcons name="alert-circle-outline" size={20} color={theme.danger} />
                <ThemedText style={[styles.saveErrorText, { color: theme.danger }]}>
                  {saveError || serverGeneralError}
                </ThemedText>
              </View>
            )}

            <Pressable
              accessibilityRole="button"
              accessibilityState={{ disabled: !formIsValid || submitting, busy: submitting }}
              disabled={!formIsValid || submitting}
              onPress={save}
              style={({ pressed }) => [
                styles.submitButton,
                {
                  backgroundColor:
                    formIsValid && !submitting ? accentColor : theme.disabled,
                },
                pressed && formIsValid && !submitting && styles.pressed,
              ]}
            >
              <ThemedText
                lightColor={BrandColors.onPrimary}
                darkColor={BrandColors.onPrimary}
                style={styles.submitLabel}
              >
                {submitting
                  ? "Guardando…"
                  : showReview
                    ? "Guardar medición"
                    : "Revisar medición"}
              </ThemedText>
              {submitting ? (
                <ActivityIndicator color={BrandColors.onPrimary} />
              ) : (
                <MaterialCommunityIcons
                  name={showReview ? "check-circle-outline" : "arrow-right"}
                  size={22}
                  color={BrandColors.onPrimary}
                />
              )}
            </Pressable>

            <View style={styles.integrationNote}>
              <MaterialCommunityIcons
                name="shield-check-outline"
                size={19}
                color={theme.icon}
              />
              <ThemedText style={[styles.integrationText, { color: theme.icon }]}>
                Verifica que los valores coincidan con tu dispositivo antes de
                continuar.
              </ThemedText>
            </View>
            </>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      {flowState.step === "confirming" && (
        <ReadingConfirmationModal
          visible
          reading={flowState.reading}
          summary={submittedSummary}
          busy={flowState.busy}
          error={flowState.error}
          theme={theme}
          onConfirm={confirmReading}
          onCancel={flow.cancel}
          onRefresh={flow.refresh}
          onGoToHistory={goToHistory}
        />
      )}
    </ThemedView>
  );
}

type MeasurementInputProps = {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  unit: string;
  placeholder: string;
  inputColor: string;
  borderColor: string;
  textColor: string;
  placeholderColor: string;
  decimal?: boolean;
  hint?: string;
  error?: string;
};

function MeasurementInput({
  label,
  value,
  onChangeText,
  unit,
  placeholder,
  inputColor,
  borderColor,
  textColor,
  placeholderColor,
  decimal = false,
  hint,
  error,
}: MeasurementInputProps) {
  return (
    <View style={styles.measurementField}>
      <ThemedText style={styles.inputLabel}>{label}</ThemedText>
      <View
        style={[
          styles.measurementInputShell,
          { backgroundColor: inputColor, borderColor: error ? "#C62828" : borderColor },
        ]}
      >
        <TextInput
          accessibilityLabel={`${label} en ${unit}`}
          accessibilityHint={error ?? hint}
          keyboardType={decimal ? "decimal-pad" : "number-pad"}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={placeholderColor}
          style={[styles.measurementInput, { color: textColor }]}
          value={value}
        />
        <ThemedText style={styles.unit}>{unit}</ThemedText>
      </View>
      {error ? (
        <ThemedText style={styles.fieldError}>{error}</ThemedText>
      ) : hint ? (
        <ThemedText style={styles.fieldHint}>{hint}</ThemedText>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  saveError: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    gap: 10,
    padding: 12,
  },
  saveErrorText: { flex: 1, fontSize: 15, lineHeight: 21 },
  content: {
    gap: 17,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  hero: {
    backgroundColor: BrandColors.primary,
    borderRadius: 22,
    minHeight: 188,
    overflow: "hidden",
    padding: 20,
    position: "relative",
  },
  heroDecorationTop: {
    backgroundColor: BrandColors.heroHighlight,
    borderRadius: 80,
    height: 160,
    opacity: 0.5,
    position: "absolute",
    right: -52,
    top: -72,
    width: 160,
  },
  heroDecorationBottom: {
    backgroundColor: BrandColors.heroAccent,
    borderRadius: 65,
    bottom: -70,
    height: 130,
    left: -42,
    opacity: 0.3,
    position: "absolute",
    width: 130,
  },
  heroIcon: {
    alignItems: "center",
    backgroundColor: BrandColors.overlayStrong,
    borderColor: BrandColors.overlayBorderStrong,
    borderRadius: 13,
    borderWidth: StyleSheet.hairlineWidth,
    height: 52,
    justifyContent: "center",
    width: 52,
  },
  heroTitle: {
    fontSize: 26,
    fontWeight: "800",
    lineHeight: 32,
    marginTop: 13,
  },
  heroDescription: {
    fontSize: 15,
    lineHeight: 22,
    marginTop: 5,
    maxWidth: 310,
  },
  sectionHeading: {
    alignItems: "center",
    flexDirection: "row",
    gap: 9,
  },
  stepBadge: {
    alignItems: "center",
    backgroundColor: BrandColors.primary,
    borderRadius: 10,
    height: 28,
    justifyContent: "center",
    width: 28,
  },
  stepBadgeText: { fontSize: 14, fontWeight: "800", lineHeight: 18 },
  sectionTitle: { fontSize: 19, fontWeight: "700", lineHeight: 25 },
  typeRow: { flexDirection: "row", gap: 9 },
  typeCard: {
    alignItems: "center",
    borderRadius: 15,
    borderWidth: 1,
    flex: 1,
    gap: 7,
    minHeight: 112,
    padding: 12,
    position: "relative",
  },
  typeCardSelected: {
    shadowColor: BrandColors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 2,
  },
  typeIcon: {
    alignItems: "center",
    borderRadius: 11,
    height: 45,
    justifyContent: "center",
    width: 45,
  },
  typeLabel: { fontSize: 14, fontWeight: "700", lineHeight: 19 },
  checkIcon: { position: "absolute", right: 7, top: 7 },
  formCard: {
    borderRadius: 17,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 15,
    padding: 16,
    shadowColor: BrandColors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.07,
    shadowRadius: 10,
    elevation: 1,
  },
  twoColumns: { flexDirection: "row", gap: 12 },
  measurementField: { flex: 1, gap: 7 },
  fieldGroup: { gap: 7 },
  inputLabel: { fontSize: 15, fontWeight: "700", lineHeight: 20 },
  fieldHelp: { fontSize: 13, lineHeight: 19 },
  measurementInputShell: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    minHeight: 58,
    paddingHorizontal: 13,
  },
  measurementInput: {
    flex: 1,
    fontSize: 22,
    fontWeight: "700",
    minWidth: 48,
    paddingVertical: 12,
  },
  unit: { fontSize: 13, fontWeight: "600", lineHeight: 18 },
  contextOptions: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginTop: 3,
  },
  contextButton: {
    borderRadius: 10,
    borderWidth: StyleSheet.hairlineWidth,
    minHeight: 42,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  contextLabel: { fontSize: 14, fontWeight: "500", lineHeight: 20 },
  contextLabelSelected: { fontWeight: "700" },
  dateCard: { flexDirection: "row", gap: 12 },
  dateField: { flex: 1.45, gap: 7 },
  timeField: { flex: 1, gap: 7 },
  inputShell: {
    alignItems: "center",
    borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth,
    flexDirection: "row",
    gap: 8,
    minHeight: 54,
    paddingHorizontal: 12,
  },
  dateInput: { flex: 1, fontSize: 15, fontWeight: "600", paddingVertical: 10 },
  reviewCard: {
    borderRadius: 17,
    borderWidth: 1,
    flexDirection: "row",
    gap: 13,
    padding: 16,
  },
  reviewIcon: {
    alignItems: "center",
    borderRadius: 11,
    height: 46,
    justifyContent: "center",
    width: 46,
  },
  reviewCopy: { flex: 1 },
  reviewEyebrow: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.5,
    lineHeight: 15,
  },
  reviewTitle: {
    fontSize: 16,
    fontWeight: "700",
    lineHeight: 22,
    marginTop: 2,
  },
  reviewValue: {
    fontSize: 21,
    fontWeight: "800",
    lineHeight: 27,
    marginTop: 2,
  },
  reviewMeta: { fontSize: 14, lineHeight: 20, marginTop: 2 },
  submitButton: {
    alignItems: "center",
    borderRadius: 14,
    flexDirection: "row",
    gap: 9,
    justifyContent: "center",
    minHeight: 56,
    paddingHorizontal: 18,
  },
  submitLabel: { fontSize: 17, fontWeight: "800", lineHeight: 23 },
  integrationNote: {
    alignItems: "flex-start",
    flexDirection: "row",
    gap: 8,
    justifyContent: "center",
    paddingHorizontal: 12,
  },
  integrationText: { flex: 1, fontSize: 13, lineHeight: 19 },
  pressed: { opacity: 0.76 },
  typeCardDisabled: { opacity: 0.45 },
  fieldHint: { fontSize: 12, lineHeight: 16, opacity: 0.7 },
  fieldError: { color: "#C62828", fontSize: 12, fontWeight: "600", lineHeight: 16 },
  statusCard: {
    alignItems: "center",
    borderRadius: 17,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 10,
    padding: 20,
  },
  statusText: { fontSize: 15, lineHeight: 21, textAlign: "center" },
  retryButton: {
    borderRadius: 12,
    minHeight: 44,
    justifyContent: "center",
    paddingHorizontal: 22,
  },
  retryLabel: { fontSize: 15, fontWeight: "700" },
});
