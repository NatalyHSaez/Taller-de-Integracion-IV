"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isLocalApiErrorResponse = exports.ApiError = void 0;
exports.isApiErrorResponse = isApiErrorResponse;
exports.isClientApiErrorResponse = isClientApiErrorResponse;
exports.apiErrorFromClientPayload = apiErrorFromClientPayload;
exports.apiErrorFromPayload = apiErrorFromPayload;
exports.apiErrorFromResponse = apiErrorFromResponse;
exports.normalizeApiError = normalizeApiError;
exports.getApiErrorMessage = getApiErrorMessage;
/** Error único de HTTP, red y mocks. */
class ApiError extends Error {
    code;
    details;
    correlationId;
    status;
    constructor({ code, message, details = {}, correlationId, status }) {
        super(message);
        this.name = 'ApiError';
        this.code = code;
        this.details = details;
        this.correlationId = correlationId?.trim() || createClientCorrelationId();
        this.status = status;
    }
    /** Representación interna; no es el JSON de errores HTTP del backend. */
    toResponse() {
        return {
            error: {
                code: this.code,
                message: this.message,
                details: this.details,
                correlationId: this.correlationId,
            },
        };
    }
}
exports.ApiError = ApiError;
function createClientCorrelationId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (character) => {
        const random = Math.floor(Math.random() * 16);
        return (character === 'x' ? random : (random & 0x3) | 0x8).toString(16);
    });
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function nonEmptyString(value) {
    return typeof value === 'string' ? value.trim() || undefined : undefined;
}
function isValidationItem(value) {
    return isRecord(value) && Array.isArray(value.loc) &&
        value.loc.every((part) => typeof part === 'string' || typeof part === 'number') &&
        typeof value.msg === 'string' && typeof value.type === 'string';
}
/** Contrato HTTP con FastAPI: { detail, errorCode? }. */
function isApiErrorResponse(value) {
    return isRecord(value) &&
        (value.errorCode === undefined || typeof value.errorCode === 'string') &&
        (typeof value.detail === 'string' ||
            (Array.isArray(value.detail) && value.detail.every(isValidationItem)));
}
function isClientApiErrorResponse(value) {
    if (!isRecord(value) || !isRecord(value.error))
        return false;
    const error = value.error;
    return typeof error.code === 'string' && typeof error.message === 'string' &&
        isRecord(error.details) && typeof error.correlationId === 'string';
}
/** Alias para código que todavía denomina 'local' a la forma interna. */
exports.isLocalApiErrorResponse = isClientApiErrorResponse;
function isBackendDetailPayload(value) {
    return isRecord(value) && Object.prototype.hasOwnProperty.call(value, 'detail');
}
function fallbackCodeForStatus(status) {
    switch (status) {
        case 400: return 'INVALID_REQUEST';
        case 401: return 'AUTHENTICATION_REQUIRED';
        case 403: return 'PERMISSION_DENIED';
        case 404: return 'RESOURCE_NOT_FOUND';
        case 408: return 'REQUEST_TIMEOUT';
        case 409: return 'CONFLICT';
        case 410: return 'RESOURCE_GONE';
        case 422: return 'VALIDATION_ERROR';
        case 429: return 'TOO_MANY_REQUESTS';
        case 503: return 'SERVICE_UNAVAILABLE';
        default:
            return status !== undefined && status >= 500 ? 'SERVER_ERROR'
                : status === undefined ? 'API_ERROR' : 'HTTP_ERROR';
    }
}
function fallbackMessageForStatus(status) {
    switch (status) {
        case 400: return 'La solicitud contiene datos inválidos.';
        case 401: return 'Debes iniciar sesión para continuar.';
        case 403: return 'No posee permiso para realizar esta operación.';
        case 404: return 'El recurso solicitado no existe.';
        case 408: return 'La solicitud tardó demasiado tiempo en responder.';
        case 409: return 'La operación entra en conflicto con el estado actual.';
        case 410: return 'El recurso solicitado ya no se encuentra disponible.';
        case 422: return 'No fue posible validar los datos enviados.';
        case 429: return 'Se realizaron demasiados intentos. Intenta nuevamente más tarde.';
        case 503: return 'El servicio no se encuentra disponible temporalmente.';
        default:
            return status !== undefined && status >= 500
                ? 'El servidor no pudo completar la solicitud.'
                : status === undefined
                    ? 'Ocurrió un error al procesar la solicitud.'
                    : `La solicitud falló con código HTTP ${status}.`;
    }
}
function apiErrorFromBackendDetailPayload(payload, status, correlationId) {
    const validationDetails = Array.isArray(payload.detail) ? payload.detail : null;
    const validation = validationDetails !== null;
    const code = nonEmptyString(payload.errorCode) ?? nonEmptyString(payload.codigo_error) ??
        (validation ? 'VALIDATION_ERROR' : fallbackCodeForStatus(status));
    // No propagar input ni ctx de FastAPI, que pueden contener datos sensibles.
    const details = validation
        ? {
            validation: (validationDetails ?? [])
                .filter(isValidationItem)
                .map(({ loc, msg, type }) => ({ loc: [...loc], msg, type })),
        }
        : {};
    const detailMessage = isRecord(payload.detail)
        ? nonEmptyString(payload.detail.message)
        : nonEmptyString(payload.detail);
    return new ApiError({
        code,
        message: validation ? fallbackMessageForStatus(status ?? 422)
            : detailMessage ?? fallbackMessageForStatus(status),
        details,
        correlationId,
        status,
    });
}
function apiErrorFromClientPayload(payload, status, correlationId) {
    return new ApiError({
        code: payload.error.code,
        message: payload.error.message,
        details: payload.error.details,
        correlationId: correlationId ?? payload.error.correlationId,
        status,
    });
}
/** Acepta tanto el contrato HTTP como la forma local usada en los mocks. */
function apiErrorFromPayload(payload, status, correlationId) {
    if ('detail' in payload) {
        return apiErrorFromBackendDetailPayload(payload, status, correlationId);
    }
    return apiErrorFromClientPayload(payload, status, correlationId);
}
/** Convierte una respuesta HTTP fallida a ApiError sin exponer HTML ni datos de validación. */
async function apiErrorFromResponse(response, requestCorrelationId) {
    const responseCorrelationId = nonEmptyString(response.headers.get('x-correlation-id'));
    const correlationId = responseCorrelationId ?? requestCorrelationId;
    let text = '';
    try {
        text = (await response.text()).trim();
    }
    catch { /* Cuerpo no disponible. */ }
    let payload;
    if (text) {
        try {
            payload = JSON.parse(text);
        }
        catch { /* Respuesta no JSON. */ }
    }
    if (isClientApiErrorResponse(payload)) {
        return apiErrorFromClientPayload(payload, response.status, correlationId);
    }
    if (isBackendDetailPayload(payload)) {
        return apiErrorFromBackendDetailPayload(payload, response.status, correlationId);
    }
    // Mantener mensajes de texto cortos del Gateway (como lo hacía main).
    // Nunca mostrar HTML, JSON ilegible, traza de servidor ni respuestas extensas.
    const contentType = response.headers.get('content-type') ?? '';
    const plainText = !payload && text.length > 0 && text.length <= 300 &&
        !/[<>]/.test(text) && !/traceback|stack trace|exception at/i.test(text) &&
        !/html|json/i.test(contentType);
    return new ApiError({
        code: fallbackCodeForStatus(response.status),
        message: plainText ? text : fallbackMessageForStatus(response.status),
        details: {}, correlationId, status: response.status,
    });
}
/** Recibe errores desconocidos de JS, respuestas del backend o mocks. */
function normalizeApiError(cause, fallbackMessage = 'Ocurrió un error inesperado.') {
    if (cause instanceof ApiError)
        return cause;
    if (isClientApiErrorResponse(cause))
        return apiErrorFromClientPayload(cause);
    if (isBackendDetailPayload(cause))
        return apiErrorFromBackendDetailPayload(cause);
    if (cause instanceof Error) {
        return new ApiError({ code: 'CLIENT_ERROR', message: cause.message || fallbackMessage });
    }
    return new ApiError({ code: 'UNKNOWN_ERROR', message: fallbackMessage });
}
/** Mensaje legible para UI; lógica funcional debe usar error.code. */
function getApiErrorMessage(cause, fallbackMessage) {
    return normalizeApiError(cause, fallbackMessage).message;
}
