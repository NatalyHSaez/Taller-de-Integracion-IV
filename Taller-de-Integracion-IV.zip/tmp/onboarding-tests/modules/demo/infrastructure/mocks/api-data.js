"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MOCK_CONSULTATIONS = exports.MOCK_DOCTOR_RELATIONSHIPS = exports.MOCK_CAREGIVER_RELATIONSHIPS = exports.MOCK_DOCTORS = exports.MOCK_NOTIFICATIONS = exports.MOCK_ALERTS = exports.MOCK_EVALUATIONS = exports.MOCK_READINGS = exports.MOCK_PATIENT_CONDITIONS = exports.MOCK_PARAMETER_LIMITS = exports.MOCK_CLINICAL_PARAMETERS = exports.MOCK_HEALTH_CONDITIONS = exports.MOCK_PATIENT_PROFILES = exports.MOCK_PATIENTS = exports.MOCK_AUTH_TOKENS = exports.MOCK_ACCOUNTS = void 0;
exports.MOCK_ACCOUNTS = [
    {
        userId: '11111111-1111-4111-8111-111111111111',
        firstName: 'Juan',
        lastName: 'Pérez',
        email: 'paciente@ejemplo.com',
        password: 'Paciente123',
        role: 'PATIENT',
        patientId: '22222222-2222-4222-8222-222222222222',
    },
    {
        userId: '16161616-1616-4616-8616-161616161616',
        firstName: 'Roberto',
        lastName: 'Pérez',
        email: 'roberto@ejemplo.com',
        password: 'Roberto123',
        role: 'PATIENT',
        patientId: '33333333-3333-4333-8333-333333333333',
    },
    {
        userId: '13131313-1313-4313-8313-131313131313',
        firstName: 'Carla',
        lastName: 'Soto',
        email: 'cuidador@ejemplo.com',
        password: 'Cuidador123',
        role: 'CAREGIVER',
    },
    {
        userId: 'ffffffff-ffff-4fff-8fff-fffffffffff1',
        firstName: 'Ana',
        lastName: 'González',
        email: 'medico@ejemplo.com',
        password: 'Medico123',
        role: 'DOCTOR',
        doctorId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeee1',
    },
];
exports.MOCK_AUTH_TOKENS = {
    accessToken: 'mock-access-token',
    refreshToken: 'mock-refresh-token',
    tokenType: 'bearer',
    expiresIn: 900,
};
exports.MOCK_PATIENTS = [
    {
        patientId: '22222222-2222-4222-8222-222222222222',
        fullName: 'Juan Pérez', relationshipId: '12121212-1212-4212-8212-121212121212',
        relationshipType: 'CAREGIVER',
        permissions: ['PATIENT_PROFILE_VIEW', 'MEASUREMENT_CREATE', 'MEASUREMENT_VIEW', 'ALERT_VIEW'],
        linkedAt: '2026-09-01T12:00:00Z',
    },
    {
        patientId: '33333333-3333-4333-8333-333333333333',
        fullName: 'Roberto Pérez', relationshipId: '19191919-1919-4919-8919-191919191919',
        relationshipType: 'CAREGIVER', permissions: ['MEASUREMENT_VIEW'],
        linkedAt: '2026-09-01T12:00:00Z',
    },
];
exports.MOCK_PATIENT_PROFILES = [
    { id: '22222222-2222-4222-8222-222222222222', fullName: 'Juan Pérez',
        birthDate: '1981-04-12', age: 45, biologicalSex: 'MALE', managementMode: 'AUTONOMOUS' },
    { id: '33333333-3333-4333-8333-333333333333', fullName: 'Roberto Pérez',
        birthDate: '1948-09-03', age: 78, biologicalSex: 'MALE', managementMode: 'ASSISTED' },
];
exports.MOCK_HEALTH_CONDITIONS = [
    {
        conditionId: '44444444-4444-4444-8444-444444444441',
        code: 'HTA',
        name: 'Hipertensión arterial',
        active: true,
        parameters: [
            { code: 'SBP', required: true },
            { code: 'DBP', required: true },
            { code: 'HEART_RATE', required: false },
        ],
    },
    {
        conditionId: '44444444-4444-4444-8444-444444444442',
        code: 'DM2',
        name: 'Diabetes mellitus tipo 2',
        active: true,
        parameters: [
            { code: 'GLUCOSE', required: true },
            { code: 'WEIGHT', required: false },
        ],
    },
];
exports.MOCK_CLINICAL_PARAMETERS = [
    {
        code: 'SBP',
        name: 'Presión sistólica',
        valueType: 'NUMBER',
        unit: 'mmHg',
        technicalMin: 50,
        technicalMax: 300,
    },
    {
        code: 'DBP',
        name: 'Presión diastólica',
        valueType: 'NUMBER',
        unit: 'mmHg',
        technicalMin: 30,
        technicalMax: 200,
    },
    {
        code: 'HEART_RATE',
        name: 'Frecuencia cardíaca',
        valueType: 'NUMBER',
        unit: 'bpm',
        technicalMin: 20,
        technicalMax: 250,
    },
    {
        code: 'GLUCOSE',
        name: 'Glucosa capilar',
        valueType: 'NUMBER',
        unit: 'mg/dL',
        technicalMin: 20,
        technicalMax: 800,
    },
    {
        code: 'WEIGHT',
        name: 'Peso corporal',
        valueType: 'NUMBER',
        unit: 'kg',
        technicalMin: 1,
        technicalMax: 400,
    },
];
/**
 * Mock de GET /parameter-limits. Se deriva del catálogo mock para que los
 * límites existan en una sola constante.
 */
exports.MOCK_PARAMETER_LIMITS = exports.MOCK_CLINICAL_PARAMETERS.map((parameter) => ({
    parameterCode: parameter.code,
    minValue: parameter.technicalMin,
    maxValue: parameter.technicalMax,
    unit: parameter.unit,
}));
exports.MOCK_PATIENT_CONDITIONS = [
    {
        patientConditionId: '66666666-6666-4666-8666-666666666661',
        patientId: '22222222-2222-4222-8222-222222222222',
        conditionId: '44444444-4444-4444-8444-444444444441',
        monitoringProfileId: '77777777-7777-4777-8777-777777777771',
        status: 'ACTIVE',
        startedAt: '2026-01-15',
        endedAt: null,
    },
    {
        patientConditionId: '66666666-6666-4666-8666-666666666662',
        patientId: '22222222-2222-4222-8222-222222222222',
        conditionId: '44444444-4444-4444-8444-444444444442',
        monitoringProfileId: '77777777-7777-4777-8777-777777777772',
        status: 'ACTIVE',
        startedAt: '2026-02-10',
        endedAt: null,
    },
];
exports.MOCK_READINGS = [
    {
        readingId: '88888888-8888-4888-8888-888888888881',
        patientId: '22222222-2222-4222-8222-222222222222',
        recordedByUserId: '11111111-1111-4111-8111-111111111111',
        context: 'REST',
        measuredAt: '2026-09-28T12:30:00Z',
        source: 'MANUAL',
        measurements: [
            {
                measurementId: '99999999-9999-4999-8999-999999999991',
                parameterCode: 'SBP',
                valueNumeric: 128,
                valueText: null,
                unit: 'mmHg',
                validationStatus: 'PLAUSIBLE',
                confirmedByUser: false,
            },
            {
                measurementId: '99999999-9999-4999-8999-999999999992',
                parameterCode: 'DBP',
                valueNumeric: 82,
                valueText: null,
                unit: 'mmHg',
                validationStatus: 'PLAUSIBLE',
                confirmedByUser: false,
            },
            {
                measurementId: '99999999-9999-4999-8999-999999999993',
                parameterCode: 'HEART_RATE',
                valueNumeric: 72,
                valueText: null,
                unit: 'bpm',
                validationStatus: 'PLAUSIBLE',
                confirmedByUser: false,
            },
        ],
    },
    {
        readingId: '88888888-8888-4888-8888-888888888882',
        patientId: '22222222-2222-4222-8222-222222222222',
        recordedByUserId: '11111111-1111-4111-8111-111111111111',
        context: 'PREPRANDIAL',
        measuredAt: '2026-09-28T10:00:00Z',
        source: 'MANUAL',
        measurements: [
            {
                measurementId: '99999999-9999-4999-8999-999999999994',
                parameterCode: 'GLUCOSE',
                valueNumeric: 120,
                valueText: null,
                unit: 'mg/dL',
                validationStatus: 'PLAUSIBLE',
                confirmedByUser: false,
            },
        ],
    },
];
exports.MOCK_EVALUATIONS = [
    {
        evaluationId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1',
        patientId: '22222222-2222-4222-8222-222222222222',
        readingId: '88888888-8888-4888-8888-888888888881',
        ruleProfileId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1',
        ruleProfileVersion: 1,
        status: 'NORMAL',
        severity: null,
        resultCode: 'HTA_WITHIN_REFERENCE',
        explanation: 'Lectura evaluada con el perfil HTA_RULES v1.',
        evaluatedAt: '2026-09-28T12:30:05Z',
    },
    {
        evaluationId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2',
        patientId: '22222222-2222-4222-8222-222222222222',
        readingId: '88888888-8888-4888-8888-888888888882',
        ruleProfileId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb2',
        ruleProfileVersion: 1,
        status: 'NORMAL',
        severity: null,
        resultCode: 'DM2_WITHIN_REFERENCE',
        explanation: 'Lectura evaluada con el perfil DM2_RULES v1.',
        evaluatedAt: '2026-09-28T10:00:05Z',
    },
];
exports.MOCK_ALERTS = [
    {
        id: 'cccccccc-cccc-4ccc-8ccc-ccccccccccc1',
        alertId: 'cccccccc-cccc-4ccc-8ccc-ccccccccccc1',
        patientId: '22222222-2222-4222-8222-222222222222',
        readingId: '88888888-8888-4888-8888-888888888883',
        measurementId: '99999999-9999-4999-8999-999999999995',
        evaluationId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3',
        ruleProfileId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1',
        ruleProfileVersion: 1,
        ruleCode: 'HTA_WARNING',
        severity: 'ADVERTENCIA',
        explanation: 'Ejemplo simulado de una alerta generada por una regla clínica.',
        status: 'OPEN',
        createdAt: '2026-09-27T18:00:05Z',
        updatedAt: '2026-09-27T18:00:05Z',
        readAt: null,
        closedAt: null,
    },
];
exports.MOCK_NOTIFICATIONS = [
    {
        id: 'dddddddd-dddd-4ddd-8ddd-ddddddddddd1',
        type: 'ALERT', title: 'Nueva alerta clínica',
        body: 'Se generó una alerta para una lectura reciente.',
        status: 'pending', readAt: null, createdAt: '2026-09-27T18:00:10Z',
    },
];
exports.MOCK_DOCTORS = [
    {
        doctorId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeee1',
        userId: 'ffffffff-ffff-4fff-8fff-fffffffffff1',
        firstName: 'Ana',
        lastName: 'González',
        profession: 'Médico',
        registryStatus: 'VERIFIED',
        verifiedAt: '2026-09-20T15:00:00Z',
    },
];
exports.MOCK_CAREGIVER_RELATIONSHIPS = [
    {
        relationshipId: '12121212-1212-4212-8212-121212121212',
        userId: '13131313-1313-4313-8313-131313131313',
        caregiverUserId: '13131313-1313-4313-8313-131313131313',
        fullName: 'Carla Soto',
        linkedAt: '2026-09-01T12:00:00Z',
        patientId: '22222222-2222-4222-8222-222222222222',
        status: 'ACTIVE',
        permissions: [
            'PATIENT_PROFILE_VIEW',
            'MEASUREMENT_CREATE',
            'MEASUREMENT_VIEW',
            'ALERT_VIEW',
        ],
        createdAt: '2026-09-01T12:00:00Z',
        revokedAt: null,
    },
];
exports.MOCK_DOCTOR_RELATIONSHIPS = [
    {
        relationshipId: '14141414-1414-4414-8414-141414141414',
        userId: 'ffffffff-ffff-4fff-8fff-fffffffffff1',
        fullName: 'Ana González', linkedAt: '2026-09-15T12:00:00Z',
        doctorId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeee1',
        doctorUserId: 'ffffffff-ffff-4fff-8fff-fffffffffff1',
        patientId: '22222222-2222-4222-8222-222222222222',
        status: 'ACTIVE',
        permissions: [
            'PATIENT_PROFILE_VIEW',
            'MEASUREMENT_VIEW',
            'ALERT_VIEW',
            'CLINICAL_VISIT_VIEW',
            'CLINICAL_VISIT_CREATE',
            'PRESCRIPTION_CREATE',
            'PRESCRIPTION_VIEW',
            'DOCUMENT_CREATE',
            'DOCUMENT_VIEW',
        ],
        createdAt: '2026-09-15T12:00:00Z',
        revokedAt: null,
    },
];
exports.MOCK_CONSULTATIONS = [
    {
        consultationId: '15151515-1515-4515-8515-151515151515',
        patientId: '22222222-2222-4222-8222-222222222222',
        doctorId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeee1',
        occurredAt: '2026-09-22T14:30:00Z',
        reason: 'Control de seguimiento',
        clinicalImpression: null,
        observations: 'Registro simulado para desarrollo de interfaz.',
        indications: null,
        status: 'FINALIZED',
        createdAt: '2026-09-22T14:30:00Z',
        updatedAt: '2026-09-22T15:00:00Z',
        finalizedAt: '2026-09-22T15:00:00Z',
        prescriptions: [],
        documents: [],
        addenda: [],
    },
];
